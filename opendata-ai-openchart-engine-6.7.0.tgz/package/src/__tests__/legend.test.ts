import type { LayoutStrategy, Rect, ResolvedTheme } from '@opendata-ai/openchart-core';
import { resolveTheme } from '@opendata-ai/openchart-core';
import { describe, expect, it } from 'vitest';
import type { NormalizedChartSpec } from '../compiler/types';
import { computeLegend } from '../legend/compute';

const specWithColor: NormalizedChartSpec = {
  markType: 'line',
  markDef: { type: 'line' },
  data: [
    { date: '2020', value: 10, country: 'US' },
    { date: '2021', value: 20, country: 'UK' },
    { date: '2022', value: 30, country: 'Germany' },
  ],
  encoding: {
    x: { field: 'date', type: 'temporal' },
    y: { field: 'value', type: 'quantitative' },
    color: { field: 'country', type: 'nominal' },
  },
  chrome: {},
  annotations: [],
  responsive: true,
  theme: {},
  darkMode: 'off',
  labels: { density: 'auto', format: '' },
};

const specWithoutColor: NormalizedChartSpec = {
  ...specWithColor,
  encoding: {
    x: { field: 'date', type: 'temporal' },
    y: { field: 'value', type: 'quantitative' },
  },
};

const chartArea: Rect = { x: 50, y: 50, width: 500, height: 300 };
const theme: ResolvedTheme = resolveTheme();

const fullStrategy: LayoutStrategy = {
  labelMode: 'all',
  legendPosition: 'right',
  annotationPosition: 'inline',
  axisLabelDensity: 'full',
  chromeMode: 'full',
  legendMaxHeight: -1,
};

const compactStrategy: LayoutStrategy = {
  labelMode: 'none',
  legendPosition: 'top',
  annotationPosition: 'tooltip-only',
  axisLabelDensity: 'minimal',
  chromeMode: 'full',
  legendMaxHeight: -1,
};

describe('computeLegend', () => {
  it('derives entries from color encoding unique values', () => {
    const legend = computeLegend(specWithColor, fullStrategy, theme, chartArea);
    expect(legend.entries).toHaveLength(3);
    expect(legend.entries.map((e) => e.label)).toEqual(['US', 'UK', 'Germany']);
  });

  it('assigns distinct colors from the theme palette', () => {
    const legend = computeLegend(specWithColor, fullStrategy, theme, chartArea);
    const colors = legend.entries.map((e) => e.color);
    const uniqueColors = new Set(colors);
    expect(uniqueColors.size).toBe(3);
  });

  it('returns empty entries when no color encoding', () => {
    const legend = computeLegend(specWithoutColor, fullStrategy, theme, chartArea);
    expect(legend.entries).toHaveLength(0);
    expect(legend.bounds.width).toBe(0);
    expect(legend.bounds.height).toBe(0);
  });

  it('positions legend on right at full width', () => {
    const legend = computeLegend(specWithColor, fullStrategy, theme, chartArea);
    expect(legend.position).toBe('right');
    expect(legend.bounds.width).toBeGreaterThan(0);
  });

  it('positions legend on top at compact width', () => {
    const legend = computeLegend(specWithColor, compactStrategy, theme, chartArea);
    expect(legend.position).toBe('top');
    expect(legend.bounds.height).toBeGreaterThan(0);
  });

  it('returns empty entries when show is false', () => {
    const specHidden: NormalizedChartSpec = {
      ...specWithColor,
      legend: { show: false },
      hiddenSeries: [],
      seriesStyles: {},
    };
    const legend = computeLegend(specHidden, fullStrategy, theme, chartArea);
    expect(legend.entries).toHaveLength(0);
    expect(legend.bounds.width).toBe(0);
    expect(legend.bounds.height).toBe(0);
  });

  it('still shows legend when show is true', () => {
    const specShown: NormalizedChartSpec = {
      ...specWithColor,
      legend: { show: true },
      hiddenSeries: [],
      seriesStyles: {},
    };
    const legend = computeLegend(specShown, fullStrategy, theme, chartArea);
    expect(legend.entries).toHaveLength(3);
  });

  it('with columns: 3 and 6 series, shows all 6 entries across 2 rows', () => {
    const sixSeriesSpec: NormalizedChartSpec = {
      ...specWithColor,
      data: [
        { date: '2020', value: 10, country: 'A' },
        { date: '2020', value: 10, country: 'B' },
        { date: '2020', value: 10, country: 'C' },
        { date: '2020', value: 10, country: 'D' },
        { date: '2020', value: 10, country: 'E' },
        { date: '2020', value: 10, country: 'F' },
      ],
      legend: { columns: 3 },
      hiddenSeries: [],
      seriesStyles: {},
    };
    const legend = computeLegend(sixSeriesSpec, compactStrategy, theme, chartArea);
    // All 6 entries visible (no overflow indicator)
    expect(legend.entries).toHaveLength(6);
    expect(legend.entries.every((e) => !e.overflow)).toBe(true);
  });

  it('with symbolLimit: 3 and 6 series, truncates to 3 entries + overflow', () => {
    const sixSeriesSpec: NormalizedChartSpec = {
      ...specWithColor,
      data: [
        { date: '2020', value: 10, country: 'A' },
        { date: '2020', value: 10, country: 'B' },
        { date: '2020', value: 10, country: 'C' },
        { date: '2020', value: 10, country: 'D' },
        { date: '2020', value: 10, country: 'E' },
        { date: '2020', value: 10, country: 'F' },
      ],
      legend: { symbolLimit: 3 },
      hiddenSeries: [],
      seriesStyles: {},
    };
    const legend = computeLegend(sixSeriesSpec, compactStrategy, theme, chartArea);
    // 3 real entries + 1 overflow indicator
    expect(legend.entries).toHaveLength(4);
    expect(legend.entries[3].label).toBe('+3 more');
    expect(legend.entries[3].overflow).toBe(true);
  });

  it('with symbolLimit on right-positioned legend, truncates entries', () => {
    const sixSeriesSpec: NormalizedChartSpec = {
      ...specWithColor,
      data: [
        { date: '2020', value: 10, country: 'A' },
        { date: '2020', value: 10, country: 'B' },
        { date: '2020', value: 10, country: 'C' },
        { date: '2020', value: 10, country: 'D' },
        { date: '2020', value: 10, country: 'E' },
        { date: '2020', value: 10, country: 'F' },
      ],
      legend: { symbolLimit: 2 },
      hiddenSeries: [],
      seriesStyles: {},
    };
    const legend = computeLegend(sixSeriesSpec, fullStrategy, theme, chartArea);
    // 2 real entries + 1 overflow indicator
    expect(legend.entries).toHaveLength(3);
    expect(legend.entries[2].label).toBe('+4 more');
    expect(legend.entries[2].overflow).toBe(true);
  });

  it('symbolLimit: 0 is clamped to 1 (minimum 1 entry)', () => {
    const sixSeriesSpec: NormalizedChartSpec = {
      ...specWithColor,
      data: [
        { date: '2020', value: 10, country: 'A' },
        { date: '2020', value: 10, country: 'B' },
        { date: '2020', value: 10, country: 'C' },
      ],
      encoding: {
        x: { field: 'date', type: 'temporal' },
        y: { field: 'value', type: 'quantitative' },
        color: { field: 'country', type: 'nominal' },
      },
    };
    const compactStrategy: LayoutStrategy = {
      legend: { symbolLimit: 0 },
      hiddenSeries: [],
      seriesStyles: {},
    };
    const legend = computeLegend(sixSeriesSpec, compactStrategy, theme, chartArea);
    // symbolLimit: 0 gets clamped to 1, so 1 real entry + overflow
    expect(legend.entries.length).toBeGreaterThanOrEqual(1);
    expect(legend.entries.filter((e) => !e.overflow).length).toBeGreaterThanOrEqual(1);
  });

  it('symbolLimit greater than entry count shows all entries', () => {
    const largeLimit: LayoutStrategy = {
      legend: { symbolLimit: 100 },
      hiddenSeries: [],
      seriesStyles: {},
    };
    const legend = computeLegend(specWithColor, largeLimit, theme, chartArea);
    // All 3 entries shown, no overflow
    expect(legend.entries).toHaveLength(3);
    expect(legend.entries.every((e) => !e.overflow)).toBe(true);
  });

  it('uses correct swatch shape for chart type', () => {
    const lineLegend = computeLegend(specWithColor, fullStrategy, theme, chartArea);
    expect(lineLegend.entries[0].shape).toBe('line');

    const barSpec: NormalizedChartSpec = {
      ...specWithColor,
      markType: 'bar',
      markDef: { type: 'bar' },
      encoding: {
        x: { field: 'value', type: 'quantitative' },
        y: { field: 'date', type: 'nominal' },
        color: { field: 'country', type: 'nominal' },
      },
    };
    const barLegend = computeLegend(barSpec, fullStrategy, theme, chartArea);
    expect(barLegend.entries[0].shape).toBe('square');

    const scatterSpec: NormalizedChartSpec = {
      ...specWithColor,
      markType: 'point',
      markDef: { type: 'point' },
      encoding: {
        x: { field: 'value', type: 'quantitative' },
        y: { field: 'value', type: 'quantitative' },
        color: { field: 'country', type: 'nominal' },
      },
    };
    const scatterLegend = computeLegend(scatterSpec, fullStrategy, theme, chartArea);
    expect(scatterLegend.entries[0].shape).toBe('circle');
  });
});
